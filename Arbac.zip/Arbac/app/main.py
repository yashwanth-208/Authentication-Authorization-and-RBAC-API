from fastapi import FastAPI, Depends, HTTPException, status
from typing import List
from functools import wraps
from app.models import User
from app.schemas import Token, UserCreate, UserInDB
from app.security import create_access_token, verify_token
from app.crud import get_user
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

app = FastAPI()


# Root Route
@app.get("/")
async def root():
    return {"message": "Welcome to the API!"}


# Function to get the current user from the token
def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    user_data = verify_token(token)
    user = get_user(user_data["username"])  # username stored in JWT payload
    if not user:
        raise HTTPException(status_code=401, detail="Invalid user")
    return user


# Role-based access control decorator
def role_required(roles: List[str]):
    def decorator(func):
        @wraps(func)
        def wrapper(user: User = Depends(get_current_user), *args, **kwargs):
            if user.role not in roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="You do not have permission to access this resource",
                )
            return func(user=user, *args, **kwargs)

        return wrapper

    return decorator


# Route for user login, generating JWT tokens
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: UserCreate):
    user = get_user(form_data.username)
    if user and form_data.password == user["password"]:  # Check password
        access_token = create_access_token(data={"username": form_data.username})
        return {"access_token": access_token, "token_type": "bearer"}
    raise HTTPException(status_code=401, detail="Invalid credentials")


# Protected route only accessible by Admin
@app.get("/admin/")
@role_required(roles=["Admin"])
async def read_admin_data(user: User = Depends(get_current_user)):
    return {"msg": "Welcome Admin", "user": user.username}


# Protected route only accessible by Admin and Moderator
@app.get("/moderator/")
@role_required(roles=["Admin", "Moderator"])
async def read_moderator_data(user: User = Depends(get_current_user)):
    return {"msg": "Welcome Moderator", "user": user.username}


# Public route accessible by anyone
@app.get("/public/")
async def read_public():
    return {"msg": "This is a public endpoint"}
