# schemas.py
from pydantic import BaseModel
from typing import Optional


# Schema for user registration and login
class UserCreate(BaseModel):
    username: str
    email: str
    password: str  # Note that this is the raw password, not hashed

    class Config:
        orm_mode = True  # Useful if you use an ORM like SQLAlchemy, but can be omitted if not using ORM


# Schema for user data in the database (after password is hashed)
class UserInDB(BaseModel):
    username: str
    email: str
    hashed_password: str  # Hashed password for storage

    class Config:
        orm_mode = True


# Token schema to represent the response model for JWT token
class Token(BaseModel):
    access_token: str
    token_type: str

    class Config:
        orm_mode = True
