# config.py

SECRET_KEY = "your_secret_key_here"  # This should be stored securely, e.g., in an environment variable
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
