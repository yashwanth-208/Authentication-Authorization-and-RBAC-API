def get(param):
    return None